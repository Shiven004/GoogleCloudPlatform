#Write a small application that uses jinja2 framework to create and render an html statically using text file.

from jinja2 import Environment, PackageLoader, select_autoescape

def  HTML_Rendering_Static():
    env = Environment(
        loader=PackageLoader('app', 'templates'),
        autoescape=select_autoescape(['html', 'xml'])
    )
    #Read the Text file
    f = open('templates/hello_world.txt', 'r')
    has = []

    if f.mode == 'r':
        contents = f.readlines()
     
    #Copy the contents in a list
    for item in contents:
        res = item.strip('][').split(', ')

    #Now use template functionalilty to populate html file
    template = env.get_template('index.html')
    output = template.render(title=res[0], header=res[1], body=res[2])
    print(output)
    
    # to save the results
    with open("templates/index.html", "w") as fh:
        fh.write(output)
    
    f.close()
    fh.close()
    
    exit()

#Calling python function to populate html
HTML_Rendering_Static()




