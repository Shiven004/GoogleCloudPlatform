#For this, read 10 records from a db.
#a. Send this data to jinja2 via dictionary


import mysql.connector
from jinja2 import Environment, PackageLoader, select_autoescape

def connectDb():

    mydb = mysql.connector.connect(host="localhost",user="root",passwd="omsairam",database="test_db_shiv")
    if mydb:
        print("Connection successful...\n")
    else:
        print("Connection failed****\n")

    return mydb

def  ReadDB_Data():

    mydb = connectDb()
    mycursor = mydb.cursor()
    myresult = []
    mydict = {}

    sqlform = "select * from employee where empid between 101 and 111 order by empid"
    mycursor.execute(sqlform)
    myresult = list(mycursor.fetchall())

    #converting list of tuples into dcitionary
    mydict = dict((k,[v,w]) for k,v,w in myresult)

    return mydict

def renderHtmlFn():

    env = Environment(
        loader=PackageLoader('app', 'templates'),
        autoescape=select_autoescape(['html', 'xml'])
    )

    mydict = ReadDB_Data()
    template = env.get_template('index.html')
    output = template.render(_dict=mydict)
    print(output)

    # to save the results
    with open("templates/index.html", "w") as fh:
        fh.write(output)

    fh.close()
    exit()


#Calling python function to populate html
renderHtmlFn()




