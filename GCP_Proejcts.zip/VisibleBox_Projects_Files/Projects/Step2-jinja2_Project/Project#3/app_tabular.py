#For this, read 10 records from a db.
#b. In a for loop in jinja2 html template, render all the 10 records in a tabular format


#For this, read 10 records from a db.
#a. Send this data to jinja2 via dictionary


import mysql.connector
from jinja2 import Environment, PackageLoader, select_autoescape

def connectDb():

    mydb = mysql.connector.connect(host="localhost",user="root",passwd="omsairam",database="test_db_shiv")
    if mydb:
        print("Connection successful...\n")
    else:
        print("Connection failed****\n")

    return mydb

def  ReadDB_Data():

    mydb = connectDb()
    mycursor = mydb.cursor()
    myresult = []
    mydict = {}

    sqlform = "select * from employee where empid between 101 and 111 order by empid"
    mycursor.execute(sqlform)
    myresult = list(mycursor.fetchall())

    #converting list of tuples into dcitionary
    mydict = dict((k,[v,w]) for k,v,w in myresult)

    mydb.close()
    return mydict

def renderHtmlFn():

    env = Environment(
        loader=PackageLoader('app_tabular', 'templates'),
        autoescape=select_autoescape(['html', 'xml'])
    )
    mydict = {}
    mydict = ReadDB_Data()
    template = env.get_template('index_01.html')
    output_01 = template.render(_dict=mydict)
    print(output_01)

    # to save the results
    with open("templates/index_01.html", "w") as fh:
        fh.write(output_01)
        fh.close()

    exit()


#Calling python function to populate html
renderHtmlFn()




