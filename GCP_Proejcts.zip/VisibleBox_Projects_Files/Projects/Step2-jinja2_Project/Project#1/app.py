#Write a small application that uses jinja2 framework to create and render an html dynamically

from jinja2 import Environment, PackageLoader, select_autoescape

def  HTML_Rendering_Dynamically():
    env = Environment(
        loader=PackageLoader('app', 'templates'),
        autoescape=select_autoescape(['html', 'xml'])
    )
    template = env.get_template('index.html')
    mytitle = input("Enter the title \n")
    myheader = input("Enter the header details...\n")
    mybody = input("Enter the body details...\n")
    output = template.render(title=mytitle,header=myheader,body=mybody)
    print(output)
    
    # to save the results
    with open("templates/index.html", "w") as fh:
        fh.write(output)
      
    exit()

HTML_Rendering_Dynamically()