###################################################################
#
#     Purpose:
#             1.Create an application that reads data from
#               memcache and renders it to an html (using jinja2)
#            2. If data is not there in memcache, the data should 
#               be picked from an ndb database,updated into 
#               memcache and then rendered to html.
#
#     Author: Shivender Khajuria
#
#####################################################################
import cgi
import cStringIO
import logging
import urllib

from google.appengine.api import memcache
from google.appengine.api import users
from google.appengine.ext import ndb

import webapp2


class Employee(ndb.Model):
    """Models an individual Employee entry with emp_id, emp_name, and salary."""
    emp_id = ndb.StringProperty()
    emp_name = ndb.StringProperty()
    salary = ndb.StringProperty()


def employee_key(employee_name=None):
    """Constructs a Datastore key for a Employee entity with employee_name"""
    return ndb.Key('Employee', employee_name or 'default_employee')


class MainPage(webapp2.RequestHandler):
    def get(self):
        self.response.out.write('<html><body>')
        employee_name = self.request.get('employee_name')

        employees = self.get_employees(employee_name)
        stats = memcache.get_stats()

        self.response.write('<b>Cache Hits:{}</b><br>'.format(stats['hits']))
        self.response.write('<b>Cache Misses:{}</b><br><br>'.format(
                            stats['misses']))
        self.response.write(employees)

        self.response.write("""
          <form action="/sign?{}" method="post">
            <div><textarea name="emp_name" rows="3" cols="60"></textarea></div>
            <div><input type="submit" value="Sign Employee"></div>
          </form>
          <hr>
          <form>Employee name: <input value="{}" name="employee_name">
          <input type="submit" value="switch"></form>
        </body>
      </html>""".format(urllib.urlencode({'employee_name': employee_name}),
                        cgi.escape(employee_name)))

    def get_employees(self, employee_name):
        """
        get_employees()
        Checks the cache to see if there are cached employees.
        If not, call render_employees and set the cache

        Args:
          employee_name: Employee entity group key (string).

        Returns:
          A string of HTML containing employees.
        """
        employees = memcache.get('{}:employees'.format(employee_name))
        if employees is None:
            employees = self.render_employees(employee_name)
            try:
                added = memcache.add(
                    '{}:employees'.format(employee_name), employees, 10)
                if not added:
                    logging.error('Memcache set failed.')
            except ValueError:
                logging.error('Memcache set failed - data larger than 1MB')
        return employees

    def render_employees(self, employee_name):
        """
        render_employees()
        Queries the database for employees, iterate through the
        results and create the HTML.

        Args:
          employee_name: Employee entity group key (string).

        Returns:
          A string of HTML containing employees
        """
        employees = ndb.gql('SELECT * '
                            'FROM Employee '                            
                            'ORDER BY Emp_Id DESC LIMIT 10',
                            employee_key(employee_name))
        output = cStringIO.StringIO()
        for employee in employees:
            if employee.emp_id:
                output.write('<b>{}</b> wrote:'.format(employee.emp_id))
            else:
                output.write('An anonymous person wrote:')
            output.write('<blockquote>{}</blockquote>'.format(
                cgi.escape(employee.emp_name)))
        return output.getvalue()


class Employee(webapp2.RequestHandler):
    def post(self):
        # We set the same parent key on the 'Employee' to ensure each employee
        # is in the same entity group. Queries across the single entity group
        # are strongly consistent. However, the write rate to a single entity
        # group is limited to ~1/second.
        employee_name = self.request.get('employee_name')
        employee = Employee(parent=employee_key(employee_name))

        if users.get_current_user():
            employee.emp_id = users.get_current_user().nickname()

        employee.emp_name = self.request.get('emp_name')
        employee.put()
        memcache.delete('{}:employees'.format(employee_name))
        self.redirect('/?' +
                      urllib.urlencode({'employee_name': employee_name}))


app = webapp2.WSGIApplication([('/', MainPage),
                               ('/sign', Employee)],
                              debug=True)
