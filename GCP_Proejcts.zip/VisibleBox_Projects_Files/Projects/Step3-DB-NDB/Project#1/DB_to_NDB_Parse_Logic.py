####################################################################################################################################
#
# Module : NDB databse Insertion
# Author: Shivender Khajuria
# Exercise :
# 1.Create a database application which reads records from a ‘DB’ database to an ‘NDB’ database with the same set of fields.
# 2. The Coding design should be such that there should be at least 10 records in the originating database.
# b. Record reading should be done thru a GQL call with cursors
# c. Only one record should be read and copied in one url call
# d. For processing the next record, another url call should be made thru a taskqueue to which cursor returned from previous GQL call should be passed so that next # fetch can work from that point onwards
#e. When all the 10 records are copied from originating database to new database,
#log a message that the entire processing is complete. 
#
####################################################################################################################################

import configparser
from google.cloud import bigquery
from google.oauth2 import service_account
from google.cloud import ndb


#This functions fetches credentials required to access DB database.
def fetchCredentials():
    
    credentials = service_account.Credentials.from_service_account_file\
    ('C:/Users/shiva/AppData/Local/Google/CloudSDK/jinja2_app/Projects/Step3-gql/Project#1/mycredentials.json')
    config = configparser.ConfigParser()
    config.read("C:/Users/shiva/AppData/Local/Google/CloudSDK/jinja2_app/Projects/Step3-gql/Project#1/config.txt")
    project_id = config.get("configuration","project_id")    
    
    return(credentials,project_id)

#This functions fetches data from Employee table created in DB database.
def fetchRows():
    
    #fetch credentials from secret files
    credentials,project_id = fetchCredentials() 
    
    #print("Inside fetchRow using bigquery...\n")    
    client = bigquery.Client(credentials= credentials,project=project_id)
    query_job = client.query("""
      SELECT *
      FROM mydataset.Employee
      ORDER by Emp_ID
      LIMIT 1000""")
    results = query_job.result().to_dataframe()  # Waits for job to complete.
    #print("row executed succesfully.....")
    #print(results)
    
    return results

#This functions reads data from DB database to NDB database.
def myNDBfn():
    res = fetchRows()    
    emp_id = ndb.IntegerProperty(indexed=True)
    emp_name = ndb.StringProperty(indexed=True)
    salary = ndb.IntegerProperty(indexed=True)
    #res = res.values.tolist()
    emp = Employee()
        
    for row in res.index:        
        emp.emp_id =  int(res['Emp_Id'][row])
        emp.emp_name = res['Emp_Name'][row]
        emp.salary = int(res['Salary'][row])
        emp_key = emp.put()
        url_string = emp_key.urlsafe()
        print(emp)    
    print("Processing complete.......\n")
    #return emp
    
myNDBfn()
        