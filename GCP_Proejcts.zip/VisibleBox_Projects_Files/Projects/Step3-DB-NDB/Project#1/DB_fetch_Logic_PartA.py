
import configparser
from google.cloud import bigquery
from google.oauth2 import service_account


def fetchCredentials():
    credentials = service_account.Credentials.from_service_account_file \
        ('C:/Users/shiva/AppData/Local/Google/CloudSDK/jinja2_app/Projects/Step3-gql/Project#1/mycredentials.json')
    config = configparser.ConfigParser()
    config.read("C:/Users/shiva/AppData/Local/Google/CloudSDK/jinja2_app/Projects/Step3-gql/Project#1/config.txt")
    project_id = config.get("configuration", "project_id")

    return (credentials, project_id)


def fetchRows():
    # fetch credentials from secret files
    credentials, project_id = fetchCredentials()

    # print("Inside fetchRow using bigquery...\n")
    client = bigquery.Client(credentials=credentials, project=project_id)
    query_job = client.query("""
      SELECT *
      FROM mydataset.Employee
      ORDER by Emp_ID
      LIMIT 1000""")
    results = query_job.result().to_dataframe()  # Waits for job to complete.
    # print("row executed succesfully.....")
    # print(results)

    return results

res = fetchRows()